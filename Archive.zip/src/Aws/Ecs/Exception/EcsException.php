<?php
namespace Aws\Ecs\Exception;

use Aws\Common\Exception\ServiceResponseException;

/**
 * Default service exception class
 */
class EcsException extends ServiceResponseException {}

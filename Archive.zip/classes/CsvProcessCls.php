<?php
require $_SERVER['DOCUMENT_ROOT']."/tasks/vendor/autoload.php";

class CsvProcessCls{

   private $csvArr,$mysqlArr,$scpArr,$awsArr,$error,$errorStr;
   const CSV_UPLOAD_TYPE      = 1;
   const SSH_UPLOAD_TYPE      = 2;
   const AWS_UPLOAD_TYPE      = 3;
   const REQUIRED_FIELD_ERROR = 'Enter Required Field';
   const NO_FILE_SELECT       = 'No File Selected';
   const MYSQL_ERROR          = 'Mysql Connection Error';

   public function __construct(){
       $this->csvArr   = array();
       $this->mysqlArr = array();
       $this->scpArr   = array();
       $this->awsArr   = array();
       $this->errorStr = '';
   } 

   public function awsFetchData($dataArr = array()){
        
       $config =   array(
                            'key'    => $dataArr['access_key'],
                            'secret' => $dataArr['secret_key']
                        );

        $s3 = Aws\S3\S3Client::factory($config);
        $s3->registerStreamWrapper();
        
        $url = 's3://'.$dataArr['bucket_name'].'/'.$dataArr['csv_file'];
        
        $fileHandle = fopen($url, 'r');
        
        $dataArr = array('column_name'=>$dataArr['column_name'],'fileHandle'=>$fileHandle,'csv_type'=>SELF::AWS_UPLOAD_TYPE);
        $this->processCsvFile($dataArr);

   }

   public function getConnectedAndFetch($dataArr = array()) {
      
        $mysqli = new mysqli($dataArr['host'],$dataArr['user'],$dataArr['password'],$dataArr['database']);

        if($mysqli->connect_error){
           
            $this->errorStr .= SELF::MYSQL_ERROR;
        } 

        $sql    = "SELECT ".$dataArr['column']." FROM ".$dataArr['table'];  
        $result = $mysqli->query($sql);  
        if($result->num_rows > 0){

           while($row = $result->fetch_assoc()) {
               $this->mysqlArr[] = $row[$dataArr['column']];
           }

        }//end if 
    }

   public function checkFields($dataArr = array()){
       
        if(count($dataArr) > 0){
            foreach($dataArr as $key=>$val){
                if(is_array($val)){
                    foreach($val as $nestedVal){
                        if(empty($nestedVal)){
                            $this->errorStr .= SELF::REQUIRED_FIELD_ERROR;
                        }
                    }
                }
            }//end foreach
        }
        
   } 

   public function processData(){
       
        $this->checkFields($_POST);
        
        if(isset($_FILES["csv_file"])){

            //if there was an error uploading the file
            if($_FILES["csv_file"]["error"] > 0) {
                echo "Return Code: " . $_FILES["csv_file"]["error"] . "<br />";

            }else{

                //Store file in directory "upload"
                $storagename = "uploaded_file".time().".csv";
                $filePath    = $_SERVER['DOCUMENT_ROOT']."/tasks/upload/".$storagename;
                $result      = move_uploaded_file($_FILES["csv_file"]["tmp_name"], $filePath);
                if($result){

                    chmod($filePath,0777);
                    $fileHandle = fopen($filePath, "r");
                    $dataArr    = array('column_name'=>$_POST['csv_column_name'],'fileHandle'=>$fileHandle,'csv_type'=>SELF::CSV_UPLOAD_TYPE);
                    
                    $this->processCsvFile($dataArr);
                }
            }
        }else{
                $this->errorStr .= SELF::NO_FILE_SELECT;
        }
        
        if($this->errorStr == ''){
            $this->getConnectedAndFetch($_POST['mysql']);
        }
        
       if($this->errorStr == ''){
            $this->awsFetchData($_POST['aws']);
        }
        
        if($this->errorStr == ''){
             $this->scpAccessData($_POST['scp']);
        }
        
        

        if($this->errorStr == ''){
            $this->mergeArray();
        }
   }

   public function scpAccessData($dataArr = array()){
       
        $connection = ssh2_connect($dataArr['host'],$dataArr['port']);
        if (ssh2_auth_password($connection, $dataArr['user'], $dataArr['password'])) {
             $sftp       = ssh2_sftp($connection);
             $fileHandle = fopen("ssh2.sftp://".intval($connection)."/home/".$dataArr['csv_file'],'r');
             $newArr     = array('column_name'=>$dataArr['column_name'],'fileHandle'=>$fileHandle,'csv_type'=>SELF::SSH_UPLOAD_TYPE);
             $this->processCsvFile($newArr);
        }
       

   }
   public function processCsvFile($dataArr = array()){
        extract($dataArr);
        $checkRow = $colVal = 0;
        $isCol              = false;
        $returnArr          = array();
        while (($row = fgetcsv($fileHandle, 0, ",")) !== FALSE) {
           if($checkRow == 0){
             foreach($row as $colValKey=>$field){
                if($column_name == $field){
                    $colVal = $colValKey;
                    $isCol  = true; 
                }
             }//end foreach

           }else{
                if($isCol){
                    $returnArr[] = $row[$colVal]; 
                }
           }//end if-else
           $checkRow++;
        }//end while
        fclose($fileHandle); 
        if($csv_type == 1){
            $this->csvArr = $returnArr;

        }elseif($csv_type == 2){
            $this->scpArr = $returnArr;
           
        }elseif($csv_type == 3){
            $this->awsArr = $returnArr;
        }
        
        return;
   }

   public function mergeArray(){
        $awsArr   = array_unique($this->awsArr);
        $mysqlArr = array_unique($this->mysqlArr);
        $sshArr   = array_unique($this->scpArr);
        $csvArr   = array_unique($this->csvArr);
         
        $newArr      = array_merge($awsArr,$mysqlArr,$csvArr);
        $tempArr     = array();
        $responseArr = array();
        foreach($newArr as $val){
            @$tempArr[$val]++;
            if(@$tempArr[$val] == 4){
                $responseArr[] = $val;
            }
        }
        $this->showtransition($responseArr);
   }

   public function showtransition($responseArr){

     if(count($responseArr) > 0){

         echo '<div id="showDiv"></div>';
         echo '<script>
                var s = '.json_encode($responseArr).';
                 var i = 0;

                    (function loop() {
                        document.getElementById("showDiv").innerHTML += s[i]+" <br /><br />";
                        if (++i < s.length) {
                            setTimeout(loop, 3000); 
                        }
                    })(); 
              </script>';

     }
   }
}
?>
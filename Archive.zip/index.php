<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width" />
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<style>
    .form-group{
        margin-right:5px;
    }
    .row{
        margin-left:0px;
    }
    h2{
        margin:10px 0px;
    }
</style>
</head>
<body>
    <div class="container">
        <form method="post" action="/tasks/show_common.php" enctype="multipart/form-data">
        <h2>S3 Credentials</h2>
        <div class="row">
            <div class="form-group">
                <label>
                    Bucket
                </label>
                <input type="text" class="form-control" name="aws[bucket_name]" required/>
            </div>
            
            <div class="form-group">
                <label>
                    Access key
                </label>
                <input type="text" class="form-control" name="aws[access_key]" required/>
            </div>
            <div class="form-group">
                <label>
                    Secret Key
                </label>
                <input type="text" class="form-control" name="aws[secret_key]" required/>
            </div>
        </div>
        <div class="row">    
            <div class="form-group">
                <label>
                    Csv file name
                </label>
                <input type="text" class="form-control" name="aws[csv_file]" required/>
            </div>
            <div class="form-group">
                <label>
                    Csv Column name
                </label>
                <input type="text" class="form-control" name="aws[column_name]" required/>
            </div>
        </div>

        <h2>Mysql Credentials</h2>
        <div class="row">
            <div class="form-group">
                <label>
                    Host
                </label>
                <input type="text" class="form-control" name="mysql[host]" required/>
            </div>
            <div class="form-group">
                <label>
                    Port
                </label>
                <input type="text" class="form-control" name="mysql[port]" required/>
            </div>
            <div class="form-group">
                <label>
                    User
                </label>
                <input type="text" class="form-control" name="mysql[user]" required/>
            </div>
            <div class="form-group">
                <label>
                    Password
                </label>
                <input type="text" class="form-control" name="mysql[password]" required/>
            </div>
        </div>
        <div class="row">    
            <div class="form-group">
                <label>
                    Database
                </label>
                <input type="text" class="form-control" name="mysql[database]" required/>
            </div>
            <div class="form-group">
                <label>
                    Table
                </label>
                <input type="text" class="form-control" name="mysql[table]" required/>
            </div>
            <div class="form-group">
                <label>
                    Column Name
                </label>
                <input type="text" class="form-control" name="mysql[column]" required/>
            </div>
        </div>

        <h2>SCP Credentials</h2>
        <div class="row">
            <div class="form-group">
                <label>
                    Host
                </label>
                <input type="text" class="form-control" name="scp[host]" required/>
            </div>
            <div class="form-group">
                <label>
                    Port
                </label>
                <input type="text" class="form-control" name="scp[port]" required/>
            </div>
            <div class="form-group">
                <label>
                    User
                </label>
                <input type="text" class="form-control" name="scp[user]" required/>
            </div>
            <div class="form-group">
                <label>
                    Password
                </label>
                <input type="text" class="form-control" name="scp[password]" required/>
            </div>
        </div>
        <div class="row">    
            <div class="form-group">
                <label>
                    Csv file name
                </label>
                <input type="text" class="form-control" name="scp[csv_file]" required/>
            </div>
            <div class="form-group">
                <label>
                    Column name
                </label>
                <input type="text" class="form-control" name="scp[column_name]" required/>
            </div>
        </div>

        <h2>CSV File Upload</h2>
        <div class="row">
            <div class="form-group">
                <label>
                    CSv file
                </label>
                <input type="file" class="form-control" name="csv_file" required />
            </div>
            <div class="form-group">
                <label>
                   Column name
                </label>
                <input type="text" class="form-control" name="csv_column_name" required />
            </div>
        </div>

        <div class="row">
            <input type="submit" value="Submit" name="submit_btn" class="btn btn-primary" />
        </div>

        </form>
    </div>
</body>
</html>